import sys
import unittest
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.discover('tests')
    machine = sys.argv[1]
    if machine == 'local':
        fp = 'results.json'
    else:
        fp = '/autograder/results/results.json'
    with open(fp, 'w') as f:
        JSONTestRunner(visibility='visible', stream=f).run(suite)
