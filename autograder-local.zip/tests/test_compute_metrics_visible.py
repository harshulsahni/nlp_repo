import time
import unittest
import numpy as np
from glob import glob
from gradescope_utils.autograder_utils.decorators import weight, visibility, number

from submission import compute_metrics


class TestComputeMetricsV(unittest.TestCase):
    def setUp(self):
        self.thresh = 1e-4
        labels = np.array([[0, 1, 1, 0], [0, 1, 1, 0]])
        predictions = np.array([[[0, 1], [-1, 1], [-1, 1], [0, 1]], [[0, 1], [-1, 1], [-1, 1], [0, 1]]])
        self.generic_output = compute_metrics((predictions, labels))
        self.true_scores = {'precision': 0.5, 'recall': 1.0, 'f1': 0.6666666666666666, 'accuracy': 0.5}

    @weight(1)
    @number("2.4.1")
    def test_metrics_accuracy(self):
        '''
            Public Test Case: Test accuracy correctness
        '''
        key = 'accuracy'
        self.assertAlmostEqual(self.generic_output[key], self.true_scores[key], delta=self.thresh, msg=f"Solution {key} is incorrect. {self.generic_output[key]}/{self.true_scores[key]}.")

    @weight(1)
    @number("2.4.2")
    def test_metrics_precision(self):
        '''
            Public Test Case: Test precision correctness
        '''
        key = 'precision'
        self.assertAlmostEqual(self.generic_output[key], self.true_scores[key], delta=self.thresh, msg=f"Solution {key} is incorrect. {self.generic_output[key]}/{self.true_scores[key]}.")

    @weight(1)
    @number("2.4.3")
    def test_metrics_recall(self):
        '''
            Public Test Case: Test recall correctness
        '''
        key = 'recall'
        self.assertAlmostEqual(self.generic_output[key], self.true_scores[key], delta=self.thresh, msg=f"Solution {key} is incorrect. {self.generic_output[key]}/{self.true_scores[key]}.")

    @weight(1)
    @number("2.4.4")
    def test_metrics_f1(self):
        '''
            Public Test Case: Test f1 correctness
        '''
        key = 'f1'
        self.assertAlmostEqual(self.generic_output[key], self.true_scores[key], delta=self.thresh, msg=f"Solution {key} is incorrect. {self.generic_output[key]}/{self.true_scores[key]}.")


