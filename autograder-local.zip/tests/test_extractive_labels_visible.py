import time
import unittest
import numpy as np
from glob import glob
from utils import labels_selector
from gradescope_utils.autograder_utils.decorators import weight, visibility, number

from submission import process_labels_fn


class TestObtainExtractiveLabelsV(unittest.TestCase):
    def setUp(self):
        self.thresh = 1e-5

    @weight(1)
    @number("2.4.1")
    def test_extractive_labels(self, set_score=None):
        '''
            Public Test Case: Test implementation of process_labels_fn
        '''
        sents = ["facebook has two days to release all emails to a defense lawyer whose client has fled from criminal charges that he falsely claimed a majority ownership in the social media giant .", "the documents requested include details relating to a contract with paul ceglia during an 18-month stretch beginning in 2003 .", "his father told a court they believe facebook and the prosecutors were conspiring against him .", "on friday , u.s. district judge vernon broderick told facebook inc. and owner mark zuckerberg they have until monday to relinquish the information that was requested by ceglia 's lawyer , robert ross fogg .", "the order ignores zuckerberg 's request to wait until ceglia is caught before handing over the documents .", "his wife , two children and dog are also missing from their home in wellsville , 70 miles southeast of buffalo .", "the judge said he would not allow a trial to proceed unjustly ."]
        summary = "paul ceglia on the run from criminal charges he falsely claimed ownership . his family accused facebook and prosecutors of conspiring against him . judge said mark zuckerberg has two days to hand over all relevant emails . the order ignores zuckerberg 's request to wait until ceglia is found ."
        gold_labels = [0, 1, 0, 1, 0, 1, 0]

        example = {'text':sents, 'summary':summary}
        post_example = {'text': sents, 'summary': summary, "labels": gold_labels}

        result = process_labels_fn(example, labels_selector=labels_selector, max=3, is_test=False)
        # Check output format
        self.assertDictEqual(result, post_example, msg=f"Solution is incorrect. {result}/{post_example}.")
