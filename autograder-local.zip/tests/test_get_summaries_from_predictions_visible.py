import time
import unittest
import numpy as np
from glob import glob
from transformers import AutoTokenizer
from gradescope_utils.autograder_utils.decorators import weight, visibility, number

from submission import get_summaries_from_predictions, tokenize_and_mask


class TestGetSummariesV(unittest.TestCase):
    def setUp(self):
        self.thresh = 1e-5
        self.tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
        self.text = ["but she was left giggling ` out of horror and fear ' during an unforgettable exchange in which the then 67-year-old entertainer took every opportunity to touch her .",
                    "` i spent 90 minutes with the former radio 1 dj dave lee travis and i do n't think there is a part of my body that he did n't grope , ' the resulting article began .",
                    '` he fondled my foot , inched his hands up my thighs , tried to make me sit on his lap and kissed me .',
                    "` he copped a feel of my hips when i foolishly asked for a tour of his studio , stroked my chin and my back and gave me a full body hug as i left . '",
                    'when police went public on their investigation , they asked miss long if she would support a prosecution or give evidence but she declined .',
                    "he declared that ` half the country would be in jail ' if patting a woman 's bottom was a crime in the 1970s as he dismissed his accusers as ` fantasists ' ."]
        self.summary = "columnist was left giggling ` out of horror ' during unforgettable exchange . the then 67-year-old entertainer took every opportunity to touch miss long . graphic account published in sunday times five months before his arrest . police asked if she would support prosecution but miss long declined . former dj was found guilty on one charge of indecent assault yesterday ."
        self.labels = [1, 0, 0, 0, 1, 0]
        self.extractive_summary = ''.join([s if p else "" for (s, p) in zip(self.text, self.labels)])


    @weight(5)
    @number("4.4.1")
    def test_get_summaries_from_predictions(self):
        '''
            Public Test Case: Test implementation of get_summaries_from_predictions
        '''
        np.random.seed(1234)
        dataset = {'text': [self.text],
                   "summary": [self.summary],
                   'labels': [self.labels]}

        dataset_tokenized = tokenize_and_mask(dataset, self.tokenizer, max_length=512)
        dataset['labels'] = dataset_tokenized['labels']
        dataset['input_ids'] = dataset_tokenized['input_ids']
        labels = np.array(dataset['labels'][0])
        print(labels.shape)
        dataset = [{'text': dataset['text'][0],
                   "summary": dataset['summary'][0],
                   'labels': dataset['labels'][0],
                   'input_ids': dataset['input_ids'][0]}]
        predictions = np.random.uniform(0, 1, (1, labels.shape[0], 2))
        extractive_summary = "but she was left giggling ` out of horror and fear ' during an unforgettable exchange in which the then 67-year-old entertainer took every opportunity to touch her .` i spent 90 minutes with the former radio 1 dj dave lee travis and i do n't think there is a part of my body that he did n't grope , ' the resulting article began ."
        result = get_summaries_from_predictions(dataset, predictions)
        # Check output format
        self.assertEqual(result[0], extractive_summary, msg=f"Solution is incorrect. {result}/{extractive_summary}.")
