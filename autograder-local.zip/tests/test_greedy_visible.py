import time
import unittest
import numpy as np
from glob import glob
from utils import AutograderRouge
from gradescope_utils.autograder_utils.decorators import weight, visibility, number

from submission import greedy_search, bruteforce_search

class TestGreedyV(unittest.TestCase):
    def setUp(self):
        self.thresh = 1e-5

    @weight(2)
    @number("2.3.1")
    def test_greedy_search(self, set_score=None):
        '''
            Public Test Case: Test greedy_search Implementation.
        '''
        sents = ["facebook has two days to release all emails to a defense lawyer whose client has fled from criminal charges that he falsely claimed a majority ownership in the social media giant .", "the documents requested include details relating to a contract with paul ceglia during an 18-month stretch beginning in 2003 .", "his father told a court they believe facebook and the prosecutors were conspiring against him .", "on friday , u.s. district judge vernon broderick told facebook inc. and owner mark zuckerberg they have until monday to relinquish the information that was requested by ceglia 's lawyer , robert ross fogg .", "the order ignores zuckerberg 's request to wait until ceglia is caught before handing over the documents .", "his wife , two children and dog are also missing from their home in wellsville , 70 miles southeast of buffalo .", "the judge said he would not allow a trial to proceed unjustly ."]
        summary = "paul ceglia on the run from criminal charges he falsely claimed ownership . his family accused facebook and prosecutors of conspiring against him . judge said mark zuckerberg has two days to hand over all relevant emails . the order ignores zuckerberg 's request to wait until ceglia is found ."
        scorer = AutograderRouge()
        reference_solution = [1, 0, 1, 0, 1, 0, 0]

        student_solution = greedy_search(sents, summary, scorer, max=3)

        # Check 1 <= the number of selected sentences <= 3
        self.assertLessEqual(sum(student_solution), 3, msg=f"Your solution has more labels. {student_solution}.")

        # Check that labels are correct
        self.assertListEqual(student_solution, reference_solution, msg=f"Solution is incorrect. {student_solution}/{reference_solution}.")
