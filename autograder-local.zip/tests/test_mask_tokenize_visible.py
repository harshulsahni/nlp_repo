import time
import unittest
import numpy as np
from glob import glob
from transformers import AutoTokenizer
from gradescope_utils.autograder_utils.decorators import weight, visibility, number

from submission import tokenize_and_mask


class TestMaskTokenizeV(unittest.TestCase):
    def setUp(self):
        self.tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
        self.text = ["but she was left giggling ` out of horror and fear ' during an unforgettable exchange in which the then 67-year-old entertainer took every opportunity to touch her .",
                    "` i spent 90 minutes with the former radio 1 dj dave lee travis and i do n't think there is a part of my body that he did n't grope , ' the resulting article began .",
                    '` he fondled my foot , inched his hands up my thighs , tried to make me sit on his lap and kissed me .',
                    "` he copped a feel of my hips when i foolishly asked for a tour of his studio , stroked my chin and my back and gave me a full body hug as i left . '",
                    'when police went public on their investigation , they asked miss long if she would support a prosecution or give evidence but she declined .',
                    "he declared that ` half the country would be in jail ' if patting a woman 's bottom was a crime in the 1970s as he dismissed his accusers as ` fantasists ' ."]
        self.summary = "columnist was left giggling ` out of horror ' during unforgettable exchange . the then 67-year-old entertainer took every opportunity to touch miss long . graphic account published in sunday times five months before his arrest . police asked if she would support prosecution but miss long declined . former dj was found guilty on one charge of indecent assault yesterday ."
        self.labels = [1, 0, 0, 0, 1, 0]
        self.generic_input =  {'text': [self.text],
                                'summary': [self.summary],
                                'labels': [ self.labels]}
        self.generic_reference = {'input_ids': [[101, 2021, 2016, 2001, 2187, 21783, 1036, 2041, 1997, 5469, 1998, 3571, 1005, 2076, 2019, 4895, 29278, 18150, 10880, 3863, 1999, 2029, 1996, 2059, 6163, 1011, 2095, 1011, 2214, 21751, 2165, 2296, 4495, 2000, 3543, 2014, 1012, 102, 101, 1036, 1045, 2985, 3938, 2781, 2007, 1996, 2280, 2557, 1015, 6520, 4913, 3389, 10001, 1998, 1045, 2079, 1050, 1005, 1056, 2228, 2045, 2003, 1037, 2112, 1997, 2026, 2303, 2008, 2002, 2106, 1050, 1005, 1056, 24665, 17635, 1010, 1005, 1996, 4525, 3720, 2211, 1012, 102, 101, 1036, 2002, 13545, 3709, 2026, 3329, 1010, 25330, 2010, 2398, 2039, 2026, 9222, 1010, 2699, 2000, 2191, 2033, 4133, 2006, 2010, 5001, 1998, 4782, 2033, 1012, 102, 101, 1036, 2002, 8872, 5669, 1037, 2514, 1997, 2026, 6700, 2043, 1045, 13219, 2135, 2356, 2005, 1037, 2778, 1997, 2010, 2996, 1010, 11699, 2026, 5413, 1998, 2026, 2067, 1998, 2435, 2033, 1037, 2440, 2303, 8549, 2004, 1045, 2187, 1012, 1005, 102, 101, 2043, 2610, 2253, 2270, 2006, 2037, 4812, 1010, 2027, 2356, 3335, 2146, 2065, 2016, 2052, 2490, 1037, 11537, 2030, 2507, 3350, 2021, 2016, 6430, 1012, 102, 101, 2002, 4161, 2008, 1036, 2431, 1996, 2406, 2052, 2022, 1999, 7173, 1005, 2065, 26085, 1037, 2450, 1005, 1055, 3953, 2001, 1037, 4126, 1999, 1996, 3955, 2004, 2002, 7219, 2010, 26960, 2869, 2004, 1036, 5470, 10230, 5130, 1005, 1012, 102, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
                                  'attention_mask': [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
                                  'position_ids': [[ 0.,  1.,  2.,  3.,  4.,  5.,  6.,  7.,  8.,  9., 10., 11., 12.,13., 14., 15., 16., 17., 18., 19., 20., 21., 22., 23., 24., 25.,26., 27., 28., 29., 30., 31., 32., 33., 34., 35., 36., 37.,  0., 1.,  2.,  3.,  4.,  5.,  6.,  7.,  8.,  9., 10., 11., 12., 13.,14., 15., 16., 17., 18., 19., 20., 21., 22., 23., 24., 25., 26.,27., 28., 29., 30., 31., 32., 33., 34., 35., 36., 37., 38., 39.,40., 41., 42., 43., 44.,  0.,  1.,  2.,  3.,  4.,  5.,  6.,  7., 8.,  9., 10., 11., 12., 13., 14., 15., 16., 17., 18., 19., 20.,21., 22., 23., 24., 25., 26., 27.,  0.,  1.,  2.,  3.,  4.,  5., 6.,  7.,  8.,  9., 10., 11., 12., 13., 14., 15., 16., 17., 18.,19., 20., 21., 22., 23., 24., 25., 26., 27., 28., 29., 30., 31.,32., 33., 34., 35., 36., 37., 38., 39., 40.,  0.,  1.,  2.,  3., 4.,  5.,  6.,  7.,  8.,  9., 10., 11., 12., 13., 14., 15., 16.,17., 18., 19., 20., 21., 22., 23., 24., 25., 26.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0.,  0.,  0.,  0.]]}
        self.generic_output = tokenize_and_mask(self.generic_input, self.tokenizer, max_length=512)

    @weight(1)
    @number("3.2.1")
    def test_tokenize_input_ids(self):
        '''
            Public Test Case: Test implementation of tokenize_and_mask (input_ids)
        '''
        key = 'input_ids'
        self.assertListEqual(list(self.generic_output[key][0]), list(self.generic_reference[key][0]), msg=f"Solution is incorrect, check {key}.")

    @weight(1)
    @number("3.2.2")
    def test_tokenize_attention_mask(self):
        '''
            Public Test Case: Test implementation of tokenize_and_mask (attention_mask)
        '''
        key = 'attention_mask'
        self.assertListEqual(list(self.generic_output[key][0]), list(self.generic_reference[key][0]), msg=f"Solution is incorrect, check {key}.")


    @weight(2)
    @number("3.2.5")
    def test_tokenize_position_ids(self):
        '''
            Public Test Case: Test implementation of tokenize_and_mask (position_ids)
        '''
        key = 'position_ids'
        self.assertListEqual(list(self.generic_output[key][0]), list(self.generic_reference[key][0]), msg=f"Solution is incorrect, check {key}.")
