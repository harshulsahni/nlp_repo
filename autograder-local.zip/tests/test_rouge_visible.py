import unittest
import numpy as np
from glob import glob
from gradescope_utils.autograder_utils.decorators import weight, visibility, number, partial_credit

from submission import MyRouge


class TestRougeV(unittest.TestCase):
    def setUp(self):
        self.thresh = 1e-5

    @weight(2)
    @number("1.1.1")
    def test_recall_rouge1_rouge2(self, set_score=None):
        '''
            Public Test Case: Test Rouge-Recall Implementation, including Rouge 1-recall and Rouge 2-recall, for one sentence
        '''
        model_out = ["he began by starting a five person war cabinet and included chamberlain as lord president of the council"]
        references = [["he began his premiership by forming a five-man war cabinet which included chamberlain as lord president of the council"]]
        gold_scores = {'rouge-1': {'precision': 0.7777777777777778,
                                   'recall': 0.7368421052631579,
                                   'f1': 0.7567567567567567},
                       'rouge-2': {'precision': 0.5294117647058824,
                                   'recall': 0.5,
                                   'f1': 0.5142857142857143}}
        rouge = MyRouge()
        rouge.update_batch(model_out, references)
        my_scores  = rouge.compute()
        key = "recall"
        self.assertTrue(np.abs(my_scores['rouge-1'][key]-gold_scores['rouge-1'][key]) <= self.thresh, msg=f"Your {key}-ROUGE: {my_scores['rouge-1'][key]}. Gold {key}-ROUGE: {gold_scores['rouge-1'][key]}")
        self.assertTrue(np.abs(my_scores['rouge-2'][key]-gold_scores['rouge-2'][key]) <= self.thresh, msg=f"Your {key}-ROUGE: {my_scores['rouge-2'][key]}. Gold {key}-ROUGE: {gold_scores['rouge-2'][key]}")

    @weight(2)
    @number("1.1.2")
    def test_precision_rouge1_rouge2(self):
        '''
            Public Test Case: Test Rouge-Recall Implementation, including Rouge 1-precision and Rouge 2-precision, for one sentence
        '''
        model_out = ["he began by starting a five person war cabinet and included chamberlain as lord president of the council"]
        references = [["he began his premiership by forming a five-man war cabinet which included chamberlain as lord president of the council"]]
        gold_scores = {'rouge-1': {'precision': 0.7777777777777778,
                                   'recall': 0.7368421052631579,
                                   'f1': 0.7567567567567567},
                       'rouge-2': {'precision': 0.5294117647058824,
                                   'recall': 0.5,
                                   'f1': 0.5142857142857143}}
        rouge = MyRouge()
        rouge.update_batch(model_out, references)
        my_scores  = rouge.compute()
        key = "precision"
        self.assertTrue(np.abs(my_scores['rouge-1'][key]-gold_scores['rouge-1'][key]) <= self.thresh, msg=f"Your {key}-ROUGE: {my_scores['rouge-1'][key]}. Gold {key}-ROUGE: {gold_scores['rouge-1'][key]}")
        self.assertTrue(np.abs(my_scores['rouge-2'][key]-gold_scores['rouge-2'][key]) <= self.thresh, msg=f"Your {key}-ROUGE: {my_scores['rouge-2'][key]}. Gold {key}-ROUGE: {gold_scores['rouge-2'][key]}")

    @weight(2)
    @number("1.1.3")
    def test_f1_rouge1_rouge2(self):
        '''
            Public Test Case: Test Rouge-Recall Implementation, including Rouge 1-f1 and Rouge 2-f1, for one sentence
        '''
        model_out = ["he began by starting a five person war cabinet and included chamberlain as lord president of the council"]
        references = [["he began his premiership by forming a five-man war cabinet which included chamberlain as lord president of the council"]]
        gold_scores = {'rouge-1': {'precision': 0.7777777777777778,
                                   'recall': 0.7368421052631579,
                                   'f1': 0.7567567567567567},
                       'rouge-2': {'precision': 0.5294117647058824,
                                   'recall': 0.5,
                                   'f1': 0.5142857142857143}}
        rouge = MyRouge()
        rouge.update_batch(model_out, references)
        my_scores  = rouge.compute()
        key = "f1"
        self.assertTrue(np.abs(my_scores['rouge-1'][key]-gold_scores['rouge-1'][key]) <= self.thresh, msg=f"Your {key}-ROUGE: {my_scores['rouge-1'][key]}. Gold {key}-ROUGE: {gold_scores['rouge-1'][key]}")
        self.assertTrue(np.abs(my_scores['rouge-2'][key]-gold_scores['rouge-2'][key]) <= self.thresh, msg=f"Your {key}-ROUGE: {my_scores['rouge-2'][key]}. Gold {key}-ROUGE: {gold_scores['rouge-2'][key]}")


    @weight(2)
    @number("1.1.6")
    def test_wrong_references_single(self):
        '''
            Hidden Test Case: Test Rouge Implementation for Rouge-3 for wrong reference input
        '''
        model_out = "the jury that sentenced aaron hernandez to life in prison on wednesday want the world to know that they gave the ex-new england patriots star a fair trial ."
        references = "Knowing that they gave the ex-new england patriots star a fair trial , the jury that sentenced aaron hernandez to life in prison on wednesday want the world to know."
        rouge = MyRouge()
        my_scores = rouge.compute_rouge(model_out, references, n=3)
        for key in my_scores['rouge-3']:
            self.assertTrue(my_scores['rouge-3'][key] == 0, msg=f"Your {key}-ROUGE: either failed or is not giving 0")
