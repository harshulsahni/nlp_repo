import re
import numpy as np
from rouge_score import rouge_scorer


class AutograderRouge(object):
    def __init__(self, preprocess=None, ns=[1, 2]):
        if preprocess == None:
            self.preprocess=lambda s: re.sub(r'[^\w\s]','',s.lower())
        else:
            self.preprocess = preprocess
        self.ns = ns
        self.agg_scores = {}
        for n in ns:
            self.agg_scores[f'rouge-{n}'] = {'precision': [], 'recall': [], 'f1': []}
    def compute(self):
        scores = {}
        for rn in self.agg_scores:
            scores[f'{rn}'] = {k: np.mean(self.agg_scores[f'{rn}'][k]) for k in self.agg_scores[f'{rn}']}
        return scores
    def update(self, candidate, references):
        self.compute_rouge_(candidate, references)
    def update_batch(self, candidates, references):
        assert len(candidates) == len(references)
        for candidate, references_ in zip(candidates, references):
            self.update(candidate, references_)
    def compute_rouge_(self, candidate, references):
        for n in self.ns:
            scores = self.compute_rouge(candidate, references, n=n)
            for k in scores[f'rouge-{n}']:
                self.agg_scores[f'rouge-{n}'][k].append(scores[f'rouge-{n}'][k])

    def compute_rouge(self, candidate, references, n):
        if self.preprocess != None:
            candidate = self.preprocess(candidate)
            references = [self.preprocess(reference) for reference in references]
        scorer_ = rouge_scorer.RougeScorer([f'rouge{n}'], use_stemmer=False)
        pairwisse_precision = [scorer_.score(reference, candidate)[f'rouge{n}'][0] for reference in references]
        pairwisse_recall = [scorer_.score(reference, candidate)[f'rouge{n}'][1] for reference in references]
        pairwisse_f1 = [scorer_.score(reference, candidate)[f'rouge{n}'][2] for reference in references]
        output = {f'rouge-{n}': {'precision' :  max(pairwisse_precision),
                                 'recall' : max(pairwisse_recall),
                                 'f1': max(pairwisse_f1)}}
        # END SOLUTION
        return output


def labels_selector(sents, ref, scorer, max=3):
    labels = []
    for i in range(len(sents)):
        if i %2:
            labels.append(1)
        else:
            labels.append(0)
    return labels
