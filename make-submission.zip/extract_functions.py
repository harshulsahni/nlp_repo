import os
import sys

def clean_cell(cell):
    cell_cleaned = []
    for line in cell.split('\n'):
        if len(line.strip()) == 0:
            continue
        if 'class' not in line and 'def' not in line and "  " not in line[:2]:
            continue
        cell_cleaned.append(line)
    return '\n'.join(cell_cleaned)

def fix_indentation(cell):
    lines = cell.split('\n')
    tab_size = 2 if lines[1][2] != ' ' else 4
    if tab_size == 2:
        return cell
    out_lines = []
    for line in lines:
        if line[0] == ' ':
            start_idx = line.find(line.strip()[0])
            # assert start_idx % 4 == 0, start_idx
            line_ = ["  " for _ in range(start_idx//4)]
            line = ''.join(line_) + line[start_idx:]
        out_lines.append(line)
    out_lines = '\n'.join(out_lines)
    return out_lines

def get_imports(lines):
    start_key = '# <a name="import_libraries"></a>'
    end_key = '# <a name="helper"></a>'
    start_ind = lines.find(start_key)
    end_ind = lines.find(end_key)
    lines = lines[start_ind:end_ind]
    out_lines = []
    for line in lines.split('\n'):
        if len(line.strip()) == 0:
            continue
        out_lines.append(line)
    out_lines = '\n'.join(out_lines)
    return out_lines

def get_installs(lines):
    start_key = '# <a name="install_libraries"></a>'
    end_key = '# <a name="import_libraries"></a>'
    start_ind = lines.find(start_key)
    end_ind = lines.find(end_key)
    lines = lines[start_ind:end_ind]
    libraries = []
    for line in lines.split('\n'):
        if len(line.strip()) == 0 or '#' in line:
            continue
        line = line.strip()
        library_name = line[line.find('install')+7:-2].strip()
        libraries.append(library_name)
    return libraries

def get_global_variables_helpers(lines):
    start_key = '# <a name="helper"></a>'
    end_key = '# <a name="make"></a>'
    start_ind = lines.find(start_key)
    end_ind = lines.find(end_key)
    lines = lines[start_ind:end_ind]
    out_lines = []
    for line in lines.split('\n'):
        if len(line.strip()) == 0:
            continue
        out_lines.append(line)
    out_lines = '\n'.join(out_lines)
    return out_lines


def function_extractor(py_script_name):
    with open(py_script_name,'r') as f:
        lines = f.read()
        libraries = get_installs(lines)
        print(libraries)
        imports = get_imports(lines)
        global_variables_and_helpers = get_global_variables_helpers(lines)
        key = '# <a name="part1"></a>'
        lines = lines[lines.find(key):]
        # Get all cells from the converted python script
        cells = lines.split('# In[')
        function_cells = []
        # Extract all functions and import lines and add them to functions.py
        for cell in cells:
            if 'def ' in cell:
                function_cells.append(cell)

    with open(os.path.join(sys.argv[2], "requirements.txt"), 'a') as f:
        for library in libraries:
            f.write(library)
            f.write('\n')

    with open(os.path.join(sys.argv[2], 'submission.py'),'w') as rf:
        rf.write("##"*40)
        rf.write("\n# YOUR IMPORTS\n")
        rf.write(imports)
        rf.write('\n')
        rf.write("##"*40)
        rf.write('\n\n\n')
        rf.write("##"*40)
        rf.write("\n# YOUR GLOBAL VARIABLES AND HELPERS\n")
        rf.write(global_variables_and_helpers)
        rf.write('\n')
        rf.write("##"*40)
        rf.write('\n\n\n')
        rf.write("##"*40)
        rf.write("\n# YOUR IMPLEMENTATIONS\n")
        for cell in function_cells:
            # Ignore the import line regarding google colab
            # if 'google.colab' not in cell:
            cell = clean_cell(cell)
            cell = fix_indentation(cell)
            if len(cell.strip()) == 0:
                continue
            rf.write(cell)
            rf.write('\n\n\n')
        rf.write("##"*40)

if __name__=="__main__":
    fp = sys.argv[1]
    function_extractor(fp)
