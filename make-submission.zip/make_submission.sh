#!/usr/bin/env bash

read -p "Enter .ipynb notebook filepath: " notebook_fp
read -p "Enter .txt linear summarizer summaries filepath: " linear_fp
read -p "Enter .txt MHA summarizer summaries filepath: " mha_fp

jupyter nbconvert ${notebook_fp} --to python
basename=${notebook_fp%.*}
dir=`dirname $notebook_fp`
python extract_functions.py ${basename}.py $dir

zip -r gradescope-submission.zip $dir/submission.py $dir/requirements.txt $linear_fp $mha_fp

cp $dir/submission.py .
cp $dir/requirements.txt .
